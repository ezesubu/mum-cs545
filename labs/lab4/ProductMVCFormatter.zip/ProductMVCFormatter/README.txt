Refactor of Lesson 3 ProductMVCClass
to auto fill Category in SELECT with Custom Formatter